% AlexNet test
% Beril Sirmacek
% December 19th 2017
% classify camera input with AlexNet
% Dependencies: AlexNet and Webcam packages of MatLab
%%
clear all
close all
clc
%%
% Access the trained model 
net = alexnet 
% See details of the architecture 
net.Layers 

%% Camera input:

camera = webcam; % Connect to the camera

while true   
    picture = camera.snapshot;              % Take a picture    
    picture = imresize(picture,[227,227]);  % Resize the picture
 
    
    drawnow;   
    
    sz = net.Layers(1).InputSize; 
    I = picture;
    I = I(1:sz(1),1:sz(2),1:sz(3)); 
    label = classify(net, I);
    image(picture); 
    hold on,
    title(char(label)); % Show the label
     
    % It is possible to access to the features which are extracted by a specific layer
    %layer = 'fc7'; % access to the fully connected layer 7
    %trainingFeatures = activations(net,picture,layer) % list the activation values
end


%% 